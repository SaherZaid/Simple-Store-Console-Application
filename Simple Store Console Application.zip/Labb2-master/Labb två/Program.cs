﻿Shop shop = new Shop();
shop.MainMenu();